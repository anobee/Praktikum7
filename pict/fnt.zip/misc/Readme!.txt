ENGLISH:
Be very careful and take the time to read any terms & conditions before deciding to use the font commercially.
Ignorance is not an excuse for breaking the law.

By installing or using this font, you are hereby agree to this Font Usage Agreement:

1. This font is ONLY for PERSONAL USE. No promotional or commercial use allowed.
2. You are requires a license for promotional or commercial use.
3. Commercial License available at: https://vstrdtypeworks.gumroad.com/l/darkerbunker
4. You will be charged for 100 x Standard License Price if you violate this agreement.
5. Please contact me for any inquiries or custom license
Email Support:
ganiia.hidayah@gmail.com

INDONESIA:

Berhati-hatilah dan luangkan waktu untuk membaca Syarat & Ketentuan Lisensi font ini, sebelum memutuskan untuk menggunakan font secara komersial. Ketidaktahuan bukanlah sebuah alasan untuk pelanggaran hukum.
Dengan meng-install font ini, anda dianggap telah membaca, mengerti, dan menyetujui semua Syarat & Ketentuan penggunaan font dibawah ini:

1. Lisensi font ini adalah "Personal Use".Yang berarti font ini hanya boleh digunakan untuk keperluan pribadi atau personal, bukan untuk kepentingan bisnis atau komersial, atau bukan untuk tujuan menghasilkan keuntungan; materiil maupun immateriil, baik itu untuk Perorangan/Individu, Agensi Desain Grafis atau Periklanan, Percetakan, dan Perusahaan/Korporasi.
2. DILARANG KERAS menggandakan, mendistribusikan, dan/atau menggunakan font ini untuk kepentingan bisnis atau komersial. Baik itu untuk Iklan, Promosi, TV, Film, Video, Motion Graphic, Youtube, atau untuk Logo & Kemasan Produk, atau dalam bentuk media apapun (cetak atau digital) dengan tujuan untuk menghasilkan keuntungan; materiil maupun immateriil.
3. Menggandakan, mendistribusikan, dan/atau menggunakan font ini untuk kepentingan bisnis atau komersial, tanpa izin atau tanpa membeli lisensi font terlebih dahulu dari saya sebagai Pencipta dan/atau Pemegang Hak Cipta Font adalah pelanggaran terhadap Syarat & Ketentuan Lisensi penggunaan font ini. an oleh karenanya anda akan dikenakan biaya 100 kali harga Standard License, atau sesuai dengan ketentuan yang telah diatur dalam Undang-Undang Nomor 28 Tahun 2014 Tentang Hak Cipta yang berlaku di Negara Kesatuan Republik Indonesia.

Informasi tentang Lisensi apa yang akan anda perlukan, silahkan menghubungi saya:
Email: ganiia.hidayah@gmail.com